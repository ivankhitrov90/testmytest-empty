<?php
namespace AD90\CustomNavMenu\Service;

class Panel extends \XF\Service\AbstractService
{
    public function collect(\XF\Entity\User $user, array $providerClasses)
    {
        $stats = [];
        foreach ($providerClasses as $class)
        {
            $class = $this->app->extendClass($class);
            $provider = new $class();
            if ($provider instanceof \AD90\CustomNavMenu\StatsProvider\ProviderInterface)
            { $stats = array_merge($stats, $provider->getStats($user)); }
        }
        return $stats;
    }
}
