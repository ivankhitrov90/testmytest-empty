<?php
namespace AD90\CustomNavMenu\Service;

class MenuTree
{
    public static function validUrl($url)
    {
        if (preg_match('/[\\x00-\\x20\\\\]/', $url)) { return false; }
        if (preg_match('~^https?://~i', $url)) { return filter_var($url, FILTER_VALIDATE_URL) !== false; }
        return !preg_match('/^(?:[^\/?#]*:|\/\/)/', $url);
    }

    public static function validateParents(array $parents, $maxDepth = 3, array $changedIds = null)
    {
        foreach ($parents as $id => $parent)
        {
            if ($changedIds !== null)
            {
                // Validate changed nodes and descendants; unrelated native trees may be deeper.
                $cursor = $id; $path = []; $affected = false;
                while ($cursor !== '' && !isset($path[$cursor]))
                {
                    if (in_array($cursor, $changedIds, true)) { $affected = true; break; }
                    $path[$cursor] = true;
                    $cursor = $parents[$cursor] ?? '';
                }
                if (!$affected) { continue; }
            }
            $seen = [$id => true]; $depth = 1;
            while ($parent !== '')
            {
                if (!array_key_exists($parent, $parents) || isset($seen[$parent]) || ++$depth > $maxDepth)
                { throw new \InvalidArgumentException((string)\XF::phrase('ad90_nav_parent_invalid')); }
                $seen[$parent] = true; $parent = $parents[$parent];
            }
        }
    }

    public static function apply(array $tree, array $rows, callable $allowed, callable $icon, array $nativeOrders = [])
    {
        $nodes = []; $parents = [];
        $flatten = function ($entries, $parent = '') use (&$flatten, &$nodes, &$parents, $nativeOrders)
        {
            $order = 0;
            foreach ($entries as $id=>$entry)
            {
                $order += 100;
                $children = $entry['children'] ?? [];
                $entry['children'] = [];
                $entry['_ad90_order'] = $nativeOrders[$id] ?? $order;
                $nodes[$id] = $entry;
                $parents[$id] = $parent;
                $flatten($children, $id);
            }
        };
        $flatten($tree);
        foreach ($rows as $row)
        {
            $native = $row['native_id'] !== '';
            $id = $native ? $row['native_id'] : 'ad90_'.$row['item_id'];
            // Never recreate a native node excluded by XF or another add-on.
            if ($native && !isset($nodes[$id])) { continue; }
            $managed = $native && !empty($row['native_managed']);
            if ((!$managed && !$row['enabled']) || !$allowed($row)) { unset($nodes[$id]); continue; }
            if (!$native)
            {
                $nodes[$id] = ['title'=>$row['title'], 'href'=>$row['url'], 'children'=>[],
                    'attributes'=>$row['target_blank'] ? ['target'=>'_blank', 'rel'=>'noopener noreferrer'] : []];
            }
            $nodes[$id]['ad90_mobile_enabled'] = !empty($row['mobile_enabled']);
            $nodes[$id]['ad90_mobile_section_title'] = $row['mobile_section_title'] ?? '';
            $nodes[$id]['ad90_is_group'] = !empty($row['is_group']);
            foreach (['description','section_title','menu_class'] as $field) { $nodes[$id]['ad90_'.$field] = $row[$field] ?? ''; }
            $nodes[$id]['ad90_icon_desktop_enabled'] = (bool)($row['icon_desktop_enabled'] ?? true);
            $nodes[$id]['ad90_icon_mobile_enabled'] = (bool)($row['icon_mobile_enabled'] ?? true);
            $nodes[$id]['ad90_icon'] = $icon($row['icon_id']);
            if (!empty($row['target_blank']))
            {
                $nodes[$id]['attributes']['target'] = '_blank';
                $rel = preg_split('/\s+/', trim($nodes[$id]['attributes']['rel'] ?? ''), -1, PREG_SPLIT_NO_EMPTY);
                $nodes[$id]['attributes']['rel'] = implode(' ', array_unique(array_merge($rel, ['noopener', 'noreferrer'])));
            }
            if (!$managed) { $nodes[$id]['_ad90_order'] = $row['display_order']; }
            // Real XF entries use native placement. Dynamic parents have no native entity to attach to.
            $runtimeParent = !empty($row['override_parent']) && $row['parent_key'] !== '' && !isset($nativeOrders[$row['parent_key']]);
            if (!$native || (!$managed && !empty($row['override_parent'])) || ($managed && $runtimeParent))
            { $parents[$id] = $row['parent_key']; }
        }
        $build = function ($parent, $seen = []) use (&$build, $nodes, $parents)
        {
            $entries = [];
            foreach ($nodes as $id=>$entry)
            {
                if (($parents[$id] ?? '') !== $parent || isset($seen[$id])) { continue; }
                $entry['children'] = $build($id, $seen + [$id=>true]);
                if (!empty($entry['ad90_is_group']) && !$entry['children']) { continue; }
                $entries[$id] = $entry;
            }
            uasort($entries, function ($a, $b) { return $a['_ad90_order'] <=> $b['_ad90_order']; });
            return $entries;
        };
        return $build('');
    }
}
