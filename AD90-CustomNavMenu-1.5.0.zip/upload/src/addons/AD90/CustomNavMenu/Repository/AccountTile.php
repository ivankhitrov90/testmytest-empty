<?php
namespace AD90\CustomNavMenu\Repository;

class AccountTile extends \XF\Mvc\Entity\Repository
{
    public function getVisibleTiles(\XF\Entity\User $visitor)
    {
        if (!$visitor->user_id) { return []; }
        $icons = $this->repository('AD90\CustomNavMenu:Navigation')->getIconUris();
        $router = $this->app()->router('public');
        $tiles = [];
        foreach ($this->finder('AD90\CustomNavMenu:AccountTile')->where('enabled', 1)->order(['display_order','tile_id'])->fetch() as $tile)
        {
            if ($tile->permission_id && !$visitor->hasPermission($tile->permission_group, $tile->permission_id)) { continue; }
            $icon = 'list';
            switch ($tile->link_type)
            {
                case 'my_threads':
                    if (!$visitor->canSearch()) { continue 2; }
                    $url = $router->buildLink('find-threads/started'); break;
                case 'bookmarks':
                    if (!$visitor->canViewBookmarks()) { continue 2; }
                    $url = $router->buildLink('account/bookmarks'); $icon = 'bookmark'; break;
                case 'navigation': continue 2; // Legacy personalisation tile.
                case 'account': $url = $router->buildLink('account/account-details'); $icon = 'settings'; break;
                default: $url = $tile->url;
            }
            $tiles[] = ['title'=>$tile->title ?: \XF::phrase('ad90_nav_tile_'.$tile->link_type),
                'href'=>$url, 'icon'=>$icons[$tile->icon_id] ?? [], 'default_icon'=>$icon];
        }
        return $tiles;
    }
}
