<?php
namespace AD90\CustomNavMenu\Admin\Controller;

use XF\Mvc\ParameterBag;
use AD90\CustomNavMenu\Service\Icon;

class MenuItem extends \XF\Admin\Controller\AbstractController
{
    protected function preDispatchController($action, ParameterBag $params)
    { $this->assertAdminPermission('navigation'); }

    public function actionIndex()
    {
        return $this->redirect($this->buildLink('navigation'));
    }
    public function actionToggle()
    {
        $this->assertPostOnly();
        return $this->redirect($this->buildLink('navigation'));
    }
    public function actionRefreshCatalog()
    {
        $this->assertPostOnly();
        $this->repository('AD90\CustomNavMenu:Navigation')->refreshCatalog();
        return $this->redirect($this->buildLink('navigation'), \XF::phrase('ad90_nav_catalog_refreshed'));
    }

    protected function edit($item)
    {
        if ($item->native_id && isset($this->repository('AD90\CustomNavMenu:Navigation')->getNativeOrders()[$item->native_id]))
        { return $this->redirect($this->buildLink('navigation/edit', ['navigation_id'=>$item->native_id])); }

        $parents = [];
        foreach ($this->repository('AD90\CustomNavMenu:Navigation')->getNativeItems() as $id=>$nav) { $parents[$id] = $nav['title']; }
        foreach ($this->repository('AD90\CustomNavMenu:Navigation')->getRows() as $row)
        { if (!$row['native_id'] && $row['item_id'] != $item->item_id) { $parents['ad90_'.$row['item_id']] = $row['title']; } }
        $currentIconUri = ''; $currentIconSvg = '';
        if ($item->icon_id)
        {
            $icon = $this->repository('AD90\CustomNavMenu:Navigation')->getIconUris()[$item->icon_id] ?? null;
            if ($icon) { $currentIconUri = $icon['uri']; $currentIconSvg = $icon['svg']; }
        }
        return $this->view('AD90\CustomNavMenu:MenuItem\Edit', 'ad90_nav_edit', ['currentIconSvg'=>$currentIconSvg, 'currentIconUri'=>$currentIconUri, 'item'=>$item, 'parents'=>$parents, 'counterSource'=>in_array($item->counter_source, ['native','none','threads','alerts','conversations'], true) ? $item->counter_source : 'custom']);
    }
    public function actionAdd()
    {
        $native = $this->filter('native_id', 'str');
        if (!$native) { return $this->redirect($this->buildLink('navigation/add')); }
        if ($native)
        {
            $item = $this->finder('AD90\CustomNavMenu:MenuItem')->where('native_id', $native)->fetchOne();
            if ($item) { return $this->redirect($this->buildLink('custom-nav-menu/edit', $item)); }
        }
        $item = $this->em()->create('AD90\CustomNavMenu:MenuItem'); $item->native_id = $native;
        if ($native) {
            $nav = $this->repository('AD90\CustomNavMenu:Navigation')->getNativeItems()[$native] ?? null;
            if (!$nav) { return $this->notFound(); }
            $item->display_order = $nav['display_order']; $item->parent_key = $nav['parent_key'];
        }
        return $this->edit($item);
    }
    public function actionRuntime(ParameterBag $params)
    {
        $native = (string)$params->native_id;
        $item = $this->finder('AD90\CustomNavMenu:MenuItem')->where('native_id', $native)->fetchOne();
        if (!$item)
        {
            if (!isset($this->repository('AD90\CustomNavMenu:Navigation')->getNativeItems()[$native])) { return $this->notFound(); }
            $item = $this->em()->create('AD90\CustomNavMenu:MenuItem'); $item->native_id = $native;
        }
        return $this->edit($item);
    }
    public function actionEdit(ParameterBag $params) { return $this->edit($this->assertRecordExists('AD90\CustomNavMenu:MenuItem', $params->item_id)); }
    public function actionSave(ParameterBag $params)
    {
        $this->assertPostOnly();
        $item = $params->item_id ? $this->assertRecordExists('AD90\CustomNavMenu:MenuItem', $params->item_id) : $this->em()->create('AD90\CustomNavMenu:MenuItem');
        $nativeId = $item->exists() ? $item->native_id : $this->filter('native_id', 'str');
        if (!$nativeId || isset($this->repository('AD90\CustomNavMenu:Navigation')->getNativeOrders()[$nativeId]))
        { return $this->redirect($this->buildLink('navigation')); }
        $input = $this->filter(['description'=>'str', 'is_group'=>'bool', 'mobile_enabled'=>'bool', 'icon_desktop_enabled'=>'bool', 'icon_mobile_enabled'=>'bool', 'mobile_section_title'=>'str', 'section_title'=>'str', 'menu_class'=>'str', 'override_parent'=>'bool', 'use_item_permission'=>'bool', 'counter_source'=>'str', 'native_id'=>'str', 'parent_key'=>'str', 'title'=>'str', 'url'=>'str', 'display_order'=>'uint', 'enabled'=>'bool', 'target_blank'=>'bool', 'permission_group'=>'str', 'permission_id'=>'str']);
        if (!$this->filter('use_menu_class', 'bool')) { $input['menu_class'] = ''; }
        if ($input['counter_source'] === 'custom') { $input['counter_source'] = $this->filter('counter_provider', 'str'); }
        if (!preg_match('/^[a-zA-Z0-9_]{1,50}$/D', $input['counter_source'])) { return $this->error(\XF::phrase('ad90_nav_counter_id_required')); }
        if ($item->exists()) { unset($input['native_id']); }
        $item->bulkSet($input);
        try { $icon = Icon::fromInput($this->request->getFile('icon', false, false), $this->filter('svg', 'str')); }
        catch (\InvalidArgumentException $e) { return $this->error($e->getMessage()); }
        $db = $this->app()->db(); $db->beginTransaction();
        try
        {
            $oldIcon = $item->icon_id; $newPath = '';
            if ($icon && $icon['file_path'])
            {
                $newPath = 'internal-data://ad90/custom_nav_menu/icons/' . bin2hex(random_bytes(16)) . '.' . pathinfo($icon['file_path'], PATHINFO_EXTENSION);
                \XF::fs()->write($newPath, $icon['icon_data']);
                $icon['file_path'] = $newPath; $icon['icon_data'] = '';
            }
            if ($icon) { $db->insert('xf_ad90_nav_icon', $icon); $item->icon_id = $db->lastInsertId(); }
            elseif ($this->filter('remove_icon', 'bool')) { $item->icon_id = 0; }
            $item->save();
            $db->commit();
        }
        catch (\Throwable $e) { $db->rollback(); if (!empty($newPath) && \XF::fs()->has($newPath)) { \XF::fs()->delete($newPath); } throw $e; }
        if ($oldIcon && $oldIcon != $item->icon_id) { Icon::delete($oldIcon); }
        return $this->redirect($this->buildLink('navigation'));
    }
    public function actionDelete(ParameterBag $params)
    {
        $item = $this->assertRecordExists('AD90\CustomNavMenu:MenuItem', $params->item_id);
        if ($item->native_id && isset($this->repository('AD90\CustomNavMenu:Navigation')->getNativeOrders()[$item->native_id]))
        { return $this->redirect($this->buildLink('navigation/delete', ['navigation_id'=>$item->native_id])); }
        if ($this->isPost()) { $item->delete(); return $this->redirect($this->buildLink('navigation')); }
        return $this->view('AD90\CustomNavMenu:MenuItem\Delete', 'ad90_nav_delete', ['item'=>$item]);
    }
    public function actionSort()
    {
        return $this->redirect($this->buildLink('navigation/sort'));
    }
}
