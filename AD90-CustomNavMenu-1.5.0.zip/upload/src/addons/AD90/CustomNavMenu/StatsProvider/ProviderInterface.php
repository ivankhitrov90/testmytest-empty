<?php
namespace AD90\CustomNavMenu\StatsProvider;

interface ProviderInterface
{
    public function getStats(\XF\Entity\User $user): array;
}
