<?php
namespace AD90\CustomNavMenu\StatsProvider;

class Core implements ProviderInterface
{
    public function getStats(\XF\Entity\User $user): array
    {
        return [
            ['label'=>\XF::phrase('messages'), 'icon'=>'fa-comment-alt', 'value'=>$user->message_count],
            ['label'=>\XF::phrase('reactions_received'), 'icon'=>'fa-heart', 'value'=>(int)\XF::db()->fetchOne('SELECT COUNT(*) FROM xf_reaction_content WHERE content_user_id = ? AND is_counted = 1', $user->user_id)]
        ];
    }
}
