<?php
namespace AD90\CustomNavMenu\Entity;

use XF\Mvc\Entity\Entity;
use XF\Mvc\Entity\Structure;

class AccountTile extends Entity
{
    public function getDisplayTitle()
    { return $this->title ?: \XF::phrase('ad90_nav_tile_'.$this->link_type); }

    protected function _preSave()
    {
        if ($this->link_type === 'custom' && (!$this->title || !$this->url))
        { $this->error(\XF::phrase('ad90_nav_tile_title_url_required')); }
        if ($this->url && !\AD90\CustomNavMenu\Service\MenuTree::validUrl($this->url))
        { $this->error(\XF::phrase('ad90_nav_tile_invalid_url'), 'url'); }
        if ((bool)$this->permission_group !== (bool)$this->permission_id
            || ($this->permission_id && !$this->em()->find('XF:Permission', [$this->permission_group, $this->permission_id])))
        { $this->error(\XF::phrase('ad90_nav_tile_invalid_permission')); }
    }

    protected function _postDelete()
    {
        if ($this->icon_id) { \AD90\CustomNavMenu\Service\Icon::delete($this->icon_id); }
    }

    public static function getStructure(Structure $structure)
    {
        $structure->table = 'xf_ad90_nav_account_tile';
        $structure->shortName = 'AD90\CustomNavMenu:AccountTile';
        $structure->primaryKey = 'tile_id';
        $structure->getters = ['display_title'=>true];
        $structure->columns = [
            'tile_id'=>['type'=>self::UINT, 'autoIncrement'=>true, 'nullable'=>true],
            'title'=>['type'=>self::STR, 'maxLength'=>100, 'default'=>''],
            'url'=>['type'=>self::STR, 'maxLength'=>2048, 'default'=>''],
            'link_type'=>['type'=>self::STR, 'default'=>'custom', 'allowedValues'=>['custom','my_threads','bookmarks','account']],
            'icon_id'=>['type'=>self::UINT, 'default'=>0],
            'display_order'=>['type'=>self::UINT, 'default'=>100],
            'enabled'=>['type'=>self::BOOL, 'default'=>true],
            'permission_group'=>['type'=>self::STR, 'maxLength'=>25, 'default'=>''],
            'permission_id'=>['type'=>self::STR, 'maxLength'=>25, 'default'=>'']
        ];
        return $structure;
    }
}
